/*
 *  Created on: 15 April. 2019
 *      Author: Li Zhe
 */

#ifndef AP_SERVER_H_
#define AP_SERVER_H_

void start_http_server(void);

#endif