#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "ap_server.h"
#include "esp_log.h"
#include "nvs_flash.h"

#define TAG     "2TAC DRC ESP32"

void app_main()
{
    nvs_flash_init();
    start_http_server();
}
