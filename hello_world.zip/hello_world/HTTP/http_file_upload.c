/*
 *  Created on: 24 May. 2019
 *      Author: Li Zhe
 */

#include "http_file_upload.h"

#define MAX_HTTP_RECV_BUFFER 512
#define HTTP_BUFFER_SIZE 512
static const char *TAG = "HTTP_FILE_UPLOAD";
#define HTTP_BOUNDARY "SolarServerBoundaryjg2qVIUS8teOAbN3"
char guid_fileName[100];

// ==================================================================================================
//          Local function 
// ==================================================================================================
static esp_err_t http_post_get_guid();
static bool sendFile(FILE *file, unsigned fileLenght, const char *guid);

/*****************************************************************************
*       @brief:      upload sd card's data files
*       @important:  1. please init wifi and check conection before call this function
*                    2. sd card init
*******************************************************************************/
void http_file_upload()
{
    ESP_LOGE(TAG, "start file upload");
    //======================  important! file extentions of data 
    uint8_t file_extensions_num = 4;
    static const char file_extensions[5][5] = {"inf", "MEM", "GPS", "STK"};

    //====================== temporary
    char fileNameWithDir[50];
	unsigned fileLenght = 0;
	struct stat st;
    FILE *file;
    char guid_real[100];
    bool flag_first;

    for(int i = 0; i < 1000; i++){
        flag_first = true;

        for(int j = 0; j < file_extensions_num; j++){
            //========== check file "xxxx.yyy" exist ========
            memset(fileNameWithDir, 0, sizeof(fileNameWithDir));
            sprintf(fileNameWithDir, "/sdcard/%03d.%s", i, file_extensions[j]);
            ESP_LOGE(TAG, "sending file: %s", fileNameWithDir);
            if(stat(fileNameWithDir, &st) == 0)
                fileLenght = st.st_size;
            else
                continue;
            
            file = fopen(fileNameWithDir, "rb");
            if(!file)
            {
                ESP_LOGE(TAG, "Could not open file to send through wifi");
                continue;
            }

            
            if(flag_first){
                http_post_get_guid();
                flag_first = false;
            }
            sprintf(guid_real, "%s.%s", guid_fileName, file_extensions[j]);
            sendFile(file, fileLenght, guid_real);
            fclose(file);
            // sd_delete_file(fileNameWithDir);
        }
    }
    
    ESP_LOGE(TAG, "End file upload");
}

// ==================================================================================================
//      http post for getting guid
// ==================================================================================================
esp_err_t _http_event_handler_guid_filename(esp_http_client_event_t *evt)
{
    switch(evt->event_id) {
        case HTTP_EVENT_ON_DATA:
            ESP_LOGI(TAG, "HTTP_EVENT_ON_DATA, len=%d", evt->data_len);
            memset(guid_fileName, 0, sizeof(guid_fileName));
            memcpy(guid_fileName, (char*)evt->data, evt->data_len);
            break;
        default:
            break;
    }
    return ESP_OK;
}

static esp_err_t http_post_get_guid()
{
    esp_http_client_config_t config = {
        .url = URL_GET_GUID,
        .event_handler = _http_event_handler_guid_filename,
    };
    esp_http_client_handle_t client = esp_http_client_init(&config);

    esp_err_t err = esp_http_client_perform(client);
    if (err == ESP_OK) {
        ESP_LOGI(TAG, "HTTP POST Status = %d, content_length = %d",
                esp_http_client_get_status_code(client),
                esp_http_client_get_content_length(client));
    } else {
        ESP_LOGE(TAG, "HTTP POST request failed: %s", esp_err_to_name(err));
    }

    esp_http_client_cleanup(client);
    return err;
}

// ==================================================================================================
//      file upload
// ==================================================================================================
esp_err_t _http_event_handler_fileupload(esp_http_client_event_t *evt)
{
    switch(evt->event_id) {
        case HTTP_EVENT_ERROR:
            ESP_LOGD(TAG, "HTTP_EVENT_ERROR");
            break;
        case HTTP_EVENT_ON_CONNECTED:
            ESP_LOGD(TAG, "HTTP_EVENT_ON_CONNECTED");
            break;
        case HTTP_EVENT_HEADER_SENT:
            ESP_LOGD(TAG, "HTTP_EVENT_HEADER_SENT");
            break;
        case HTTP_EVENT_ON_HEADER:
            ESP_LOGD(TAG, "HTTP_EVENT_ON_HEADER, key=%s, value=%s", evt->header_key, evt->header_value);
            break;
        case HTTP_EVENT_ON_DATA:
            ESP_LOGD(TAG, "HTTP_EVENT_ON_DATA, len=%d", evt->data_len);
            if (!esp_http_client_is_chunked_response(evt->client)) {
                // Write out data
            }

            break;
        case HTTP_EVENT_ON_FINISH:
            ESP_LOGD(TAG, "HTTP_EVENT_ON_FINISH");
            break;
        case HTTP_EVENT_DISCONNECTED:
            ESP_LOGD(TAG, "HTTP_EVENT_DISCONNECTED");
            break;
    }
    return ESP_OK;
}


static bool sendFile(FILE *file, unsigned fileLenght, const char *guid)
{
    char url_temp[200];
    // read mac address for making device unique id.
    uint8_t mac_addr[8] = {0};
    esp_efuse_mac_get_default(mac_addr);
    sprintf(url_temp, "%s?deviceId=%02x%02x%02x%02x%02x%02x%02x%02x",URL_FILEUPLOAD, mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5], mac_addr[6], mac_addr[7]);
    ESP_LOGI(TAG, "url_temp = %s\n", url_temp);

    //========================================= init http clinet ========================================
	esp_err_t err;
	esp_http_client_config_t config = {
		.url = url_temp,
		.event_handler = _http_event_handler_fileupload,
	};
	esp_http_client_handle_t client = esp_http_client_init(&config);
	ESP_LOGI(TAG, "client initialized");

	err = esp_http_client_set_method(client, HTTP_METHOD_POST);
    // esp_http_client_set_post_field(client, post_data, strlen(post_data));
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set method: %s", esp_err_to_name(err));
        esp_http_client_cleanup(client);
    }

	//Set Multipart header
	char contentTypeStr[50] = "multipart/form-data; boundary=";
	strcat(contentTypeStr, HTTP_BOUNDARY);

    err = esp_http_client_set_header(client, "Content-Type", contentTypeStr);
    err = esp_http_client_set_header(client, "User-Agent", "Test");
    err = esp_http_client_set_header(client, "Keep-Alive", "300");
    err = esp_http_client_set_header(client, "Connection", "keep-alive");
    err = esp_http_client_set_header(client, "Accept-Language", "en-us");

    //========================================= make header write ==========================================

	char contentType[] = "application/zip";

	//key header
	char keyHeader[100] = "";
	strcat(keyHeader, "--");
	strcat(keyHeader, HTTP_BOUNDARY);
	strcat(keyHeader, "\r\n");

	strcat(keyHeader, "Content-Disposition: form-data; name=\"key\"\r\n\r\n");
	strcat(keyHeader, "${filename}\r\n");
	ESP_LOGI(TAG, "keyHeader: %s", keyHeader);

	//request header
	char requestHead[200] = "";
	strcat(requestHead, "--");
	strcat(requestHead, HTTP_BOUNDARY);
	strcat(requestHead, "\r\n");
	strcat(requestHead, "Content-Disposition: form-data; name=\"file\"; filename=\"");
	strcat(requestHead, guid);
	strcat(requestHead, "\"\r\n");
	strcat(requestHead, "Content-Type: ");
	strcat(requestHead, contentType);
	strcat(requestHead, "\r\n\r\n");
	ESP_LOGI(TAG, "requestHead: %s", requestHead);

	//request tail
	char tail[50] = "";
	strcat(tail, "\r\n--");
	strcat(tail, HTTP_BOUNDARY);
	strcat(tail, "--\r\n\r\n");
	ESP_LOGI(TAG, "tail: %s", tail);

	//Set Content-Length
	int contentLength = strlen(keyHeader) + strlen(requestHead) + fileLenght + strlen(tail);
	ESP_LOGI(TAG, "length: %d", contentLength);
	char lengthStr[10];
	sprintf(lengthStr, "%i", contentLength);
    err = esp_http_client_set_header(client, "Content-Length", lengthStr);

    //=============================================================================================

    err = esp_http_client_open(client, contentLength);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to open HTTP connection: %s", esp_err_to_name(err));
        esp_http_client_cleanup(client);
        return false;
    }

	ESP_LOGI(TAG, "client connection open");

	ESP_LOGI(TAG, "keyHeader:\t%d", esp_http_client_write(client, keyHeader, strlen(keyHeader)));
	ESP_LOGI(TAG, "requestHead:\t%d", esp_http_client_write(client, requestHead, strlen(requestHead)));
	//Send file parts
	char buffer[HTTP_BUFFER_SIZE];

	unsigned fileProgress = 0;
	int length = 1;
    
	time_t fileTransferStart = 0;
	time(&fileTransferStart);
	while(length)
	{
		length = fread(buffer, sizeof(char), HTTP_BUFFER_SIZE, file);
		if(length)
		{
			int wret = esp_http_client_write(client, buffer, length);
			if(wret < 0)
				 return false;

			fileProgress += wret;
			//ESP_LOGI(TAG, "%.*s", length, buffer);
			time_t now;
			time(&now);
			if((float)(now - fileTransferStart) / 1024 > 0)
				ESP_LOGI(TAG, "%u/%u sent,%.02fKiB/s", fileProgress, fileLenght, fileProgress  / (float)(now - fileTransferStart) / 1024);
		}
	}
	//finish Multipart request
	ESP_LOGI(TAG, "tail:\t%d", esp_http_client_write(client, tail, strlen(tail)));

	//Get response
    
    int content_length =  esp_http_client_fetch_headers(client);
    int total_read_len = 0, read_len;
    if (total_read_len < content_length && content_length <= MAX_HTTP_RECV_BUFFER) {
        read_len = esp_http_client_read(client, buffer, content_length);
        if (read_len <= 0) {
            ESP_LOGE(TAG, "Error read data");
        }
        buffer[read_len] = 0;
        ESP_LOGD(TAG, "read_len = %d", read_len);
    }
    ESP_LOGI(TAG, "HTTP Stream reader Status = %d, content_length = %d",
                    esp_http_client_get_status_code(client),
                    esp_http_client_get_content_length(client));

    //========================================= cleanup http client ========================    
	err = esp_http_client_cleanup(client);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to clean HTTP connection: %s", esp_err_to_name(err));
        esp_http_client_cleanup(client);
    }

    return true;
}
