/*
 *  Created on: 15 April. 2019
 *      Author: Li Zhe
 */

#ifndef HTTP_API_H_
#define HTTP_API_H_

#include <string.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

// #include "WiFi/app_wifi.h"
#include "SD/ESP32_sd.h"
#include "PowerManagement/ESP32_power.h" // for esp32 mode

// #define URL_FIRMWARE_BUCKET "http://s3.us-east-2.amazonaws.com/oarinspired-bucket/oar-firmware-files/"
// #define URL_CHECK_VERSION   "http://inspired-env.mn9uusxec4.ap-southeast-2.elasticbeanstalk.com/api/deviceUpdate/getLatestFirmwareById"
#define URL_FIRMWARE_BUCKET "http://192.168.0.146:53266/api/deviceUpdate/downloadFirmware?firmwareUrl="
#define URL_CHECK_VERSION   "http://192.168.0.146:53266/api/deviceUpdate/getLatestFirmwareById"

// void test_OTA();
// void test_OTA_native();
// void http_test_task(void *pvParameters);


esp_err_t http_download_cc1310();
esp_err_t OTA_Update(char *url);

    // esp32 device unique id
    char esp32_device_id[17];
/*
*       @brief:      compare current version with server's last version, and if need, download firmware files
*/
void http_version_update();

/*
*       @brief:     send => upload mac_address, running_mode, current versions of esp32 and cc1310
*                   receive <= lastest versions of esp32 and cc1310
*/
void http_version_check();

#endif 