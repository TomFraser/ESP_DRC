/*
 *  Created on: 17 April. 2019
 *      Author: Li Zhe
 */

#include "http_api.h"

#define MAX_HTTP_RECV_BUFFER 512
static const char *TAG = "HTTP_API";
char buf_response[600];

// ==================================================================================================
//          Local function 
// ==================================================================================================
esp_err_t http_download_cc1310(char *file_name);
esp_err_t http_post(const char * url, const char *post_data);
esp_err_t OTA_Update_with_filename(char *file_name);

// ==================================================================================================
//          DL3 connnects to AWS
// ==================================================================================================
void http_version_check()
{    
    if(!wifi_connect()){
        ESP_LOGE(TAG, "Wifi can't connect");
        return;
    }

    char post_data[200];
    
    // read mac address for making device unique id.
    uint8_t mac_addr[8] = {0};
    esp_efuse_mac_get_default(mac_addr);
    sprintf(esp32_device_id, "%02x%02x%02x%02x%02x%02x%02x%02x", mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5], mac_addr[6], mac_addr[7]);
    ESP_LOGI(TAG, "mac address %s", esp32_device_id);

    // make a post data
    // const char *post_data = "field1=value1&field2=value2";
    if(config.firmwareVersion.array[0] == 0){
        config.firmwareVersion.array[0] = 1;
        config.firmwareVersion.array[1] = 1;
        config.firmwareVersion.array[2] = 1;
    }

    sprintf(post_data, "deviceId=%s&mode=%d&esp=%d&cc=%d", esp32_device_id, mode, config.firmwareVersion.array[0], config.firmwareVersion.array[2]);
    ESP_LOGI(TAG, "post_data = %s\n", post_data);

    if(http_post(URL_CHECK_VERSION, post_data) == ESP_OK){
        printf("result = %s\n", buf_response);
    }
}

// ==================================================================================================
//          Version update of cc1310, esp32 chips
// ==================================================================================================
void http_version_update(){    
    
    if(!wifi_connect()){
        ESP_LOGE(TAG, "Wifi can't connect");
        return;
    }

    char post_data[200];
    
    // read mac address for making device unique id.
    uint8_t mac_addr[8] = {0};
    esp_efuse_mac_get_default(mac_addr);
    sprintf(esp32_device_id, "%02x%02x%02x%02x%02x%02x%02x%02x", mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5], mac_addr[6], mac_addr[7]);
    ESP_LOGI(TAG, "mac address %s", esp32_device_id);

    // make a post data
    // const char *post_data = "field1=value1&field2=value2";
    if(config.firmwareVersion.array[0] == 0){
        config.firmwareVersion.array[0] = 1;
        config.firmwareVersion.array[1] = 1;
        config.firmwareVersion.array[2] = 1;
    }

    sprintf(post_data, "deviceId=%s&mode=%d&esp=%d&cc=%d", esp32_device_id, mode, config.firmwareVersion.array[0], config.firmwareVersion.array[2]);
    ESP_LOGI(TAG, "post_data = %s\n", post_data);
    
    if(http_post(URL_CHECK_VERSION, post_data) == ESP_OK){
        printf("result = %s\n", buf_response);
        cJSON *root = cJSON_Parse(buf_response);
        int esp32 = cJSON_GetObjectItem(root,"esp32")->valueint;
        char * esp32_url   = cJSON_GetObjectItem(root,"esp32_url")->valuestring;
        // int msp432 = cJSON_GetObjectItem(root,"msp432p401r")->valueint;
        // char * msp432_url   = cJSON_GetObjectItem(root,"msp432p401r_url")->valuestring;
        int cc1310 = cJSON_GetObjectItem(root,"cc1310")->valueint;
        char * cc1310_url   = cJSON_GetObjectItem(root,"cc1310_url")->valuestring;
        ESP_LOGI(TAG, "esp32 = %d, cc1310 = %d \n", esp32, cc1310);

        // if(msp432 > config.firmwareVersion.array[1]){
        //     ESP_LOGI(TAG, "start msp432 firmware updating");
        //     if(http_download_msp432(msp432_url) == ESP_OK){
        //         config.firmwareVersion.array[1] = msp432;
        //         SD_config_write();
        //     }
        // }
        if(cc1310 > config.firmwareVersion.array[2]){
            ESP_LOGI(TAG, "start cc1310 firmware updating");
            if(http_download_cc1310(cc1310_url) == ESP_OK){
                config.firmwareVersion.array[2] = cc1310;
                SD_config_write();
            }
        }
        if(esp32 > config.firmwareVersion.array[0]){
            ESP_LOGI(TAG, "start esp32 firmware updating");
            if(OTA_Update_with_filename(esp32_url) == ESP_OK){
                config.firmwareVersion.array[0] = esp32;
                SD_config_write();
                esp_restart();
            }
            else
                ESP_LOGE(TAG, "esp32 Firmware Upgrade Failed");
        }
    }
}

// ==================================================================================================
//      Download cc1310 firmware
// ==================================================================================================
esp_err_t _http_event_handler_cc1310(esp_http_client_event_t *evt)
{
    switch(evt->event_id) {
        case HTTP_EVENT_ON_DATA:
            ESP_LOGI(TAG, "CC1310_FILE DATA, len=%d", evt->data_len);   
            sd_append_file(CC1310_FILE, (char*)evt->data, evt->data_len);
            break;
        default:
            break;
    }
    return ESP_OK;
}

esp_err_t http_download_cc1310(char *file_name)
{
    sd_delete_file(CC1310_FILE);

    char url_temp[200];
    sprintf(url_temp, "%s%s", URL_FIRMWARE_BUCKET, file_name);
    ESP_LOGI(TAG, "url = %s\n", url_temp);

    esp_http_client_config_t config = {
        .url = url_temp,
        .event_handler = _http_event_handler_cc1310,
    };
    esp_http_client_handle_t client = esp_http_client_init(&config);
    esp_err_t err = esp_http_client_perform(client);

    if (err == ESP_OK) {
        ESP_LOGI(TAG, "HTTP chunk encoding Status = %d, content_length = %d",
                esp_http_client_get_status_code(client),
                esp_http_client_get_content_length(client));
    } else {
        ESP_LOGE(TAG, "Error perform http request %s", esp_err_to_name(err));
    }

    esp_http_client_cleanup(client);
    return err;
}

// ==================================================================================================
//      common http post
// ==================================================================================================

esp_err_t _http_event_handler(esp_http_client_event_t *evt)
{
    switch(evt->event_id) {
        case HTTP_EVENT_ON_DATA:
            ESP_LOGI(TAG, "HTTP_EVENT_ON_DATA, len=%d", evt->data_len);
            memset(buf_response, 0, sizeof(buf_response));
            memcpy(buf_response, (char*)evt->data, evt->data_len);
            break;
        default:
            break;
    }
    return ESP_OK;
}

esp_err_t http_post(const char * url, const char *post_data)
{
    
    esp_http_client_config_t config = {
        .url = url,
        .event_handler = _http_event_handler,
    };
    esp_http_client_handle_t client = esp_http_client_init(&config);

    // POST
    esp_http_client_set_method(client, HTTP_METHOD_POST);
    esp_http_client_set_post_field(client, post_data, strlen(post_data));
    esp_err_t err = esp_http_client_perform(client);
    if (err == ESP_OK) {
        ESP_LOGI(TAG, "HTTP POST Status = %d, content_length = %d",
                esp_http_client_get_status_code(client),
                esp_http_client_get_content_length(client));
    } else {
        ESP_LOGE(TAG, "HTTP POST request failed: %s", esp_err_to_name(err));
    }

    esp_http_client_cleanup(client);
    return err;
}

// ==================================================================================================
//          OTA_Update 
// ==================================================================================================
esp_err_t OTA_Update_with_filename(char *file_name)
{
    char url_temp[200];
    sprintf(url_temp, "%s%s", URL_FIRMWARE_BUCKET, file_name);
    ESP_LOGI(TAG, "url = %s\n", url_temp);

    esp_http_client_config_t config = {
        .url = url_temp,
    };
    esp_err_t ret = esp_https_ota(&config);
    return ret;
}
