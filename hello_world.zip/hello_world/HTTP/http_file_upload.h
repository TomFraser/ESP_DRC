/*
 *  Created on: 24 May. 2019
 *      Author: Li Zhe
 */

#ifndef HTTP_UPLOAD_H_
#define HTTP_UPLOAD_H_

#include <string.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "esp_vfs_fat.h"
#include "driver/sdmmc_host.h"
#include "driver/sdspi_host.h"
#include "sdmmc_cmd.h"
#include <sys/unistd.h>
#include <sys/stat.h>
#include "esp_http_client.h"

#include "SD/ESP32_sd.h"


// #define URL_FILEUPLOAD    "http://inspired-env.mn9uusxec4.ap-southeast-2.elasticbeanstalk.com/dl3/uploadFiles"
// #define URL_GET_GUID      "http://inspired-env.mn9uusxec4.ap-southeast-2.elasticbeanstalk.com/dl3/getFileName"

#define URL_FILEUPLOAD  "http://192.168.0.146:53266/dl3/uploadFiles"
#define URL_GET_GUID    "http://192.168.0.146:53266/dl3/getFileName"
/*
*       @brief:      upload sd card's data files
*       @important:  1. please init wifi and check conection before call this function
*                    2. sd card init
*/
void http_file_upload();

#endif 